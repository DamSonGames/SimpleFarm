document.addEventListener("keydown", keyDownTextField, false);

function keyDownTextField(e) {
var keyCode = e.keyCode;
  if(keyCode==49) {
      SelectPotato()
  }else if(keyCode==50) {
      SelectCarrot()
  }else if(keyCode==51) {
      SelectWheat()
  }else if(keyCode==52) {
      SelectOnion()
  }
}

var vegetable = 1;
var potatoes = 2;
var carrots = 2;
var wheat = 2;
var onions = 2;
var farm1taken = 0;
var farm2taken = 0;
var farm3taken = 0;
var farm4taken = 0;
var farm5taken = 0;
var farm6taken = 0;
var farm7taken = 0;
var farm8taken = 0;
var farm9taken = 0;
var farm10taken = 0;

document.getElementById("Potatoes").innerHTML = 2;
document.getElementById("Carrots").innerHTML = 2;
document.getElementById("Wheat").innerHTML = 2;
document.getElementById("Onions").innerHTML = 2;
document.getElementById("Line1").innerHTML = "&nbsp;"
document.getElementById("Line2").innerHTML = "&nbsp;"
document.getElementById("Line3").innerHTML = "&nbsp;"
document.getElementById("Line4").innerHTML = "&nbsp;"

function SelectPotato(){
  vegetable = 1;
  AddToConsole("Selected Potato Seeds!");
}

function SelectCarrot(){
  vegetable = 2;
  AddToConsole("Selected Carrot Seeds!");
}

function SelectWheat(){
  vegetable = 3;
  AddToConsole("Selected Wheat Seeds!");
}

function SelectOnion(){
  vegetable = 4;
  AddToConsole("Selected Onion Seeds!");
}

function Farm1(){
  if(farm1taken == 0){
    if(vegetable == 1){
      if(potatoes > 0){
        farm1taken = 11;
        potatoes -= 1;
        UpdateStock();
        document.getElementById("Image1").src = "Images/Potato/Potato1.png";
        setTimeout(UpdateFarm1, 60000);
      }
    }else if(vegetable == 2){
      if(carrots > 0){
        farm1taken = 21;
        carrots -= 1;
        UpdateStock();
        document.getElementById("Image1").src = "Images/Carrot/Carrot1.png";
        setTimeout(UpdateFarm1, 50000);
      }
    }else if(vegetable == 3){
      if(wheat > 0){
        farm1taken = 31;
        wheat -= 1;
        UpdateStock();
        document.getElementById("Image1").src = "Images/Wheat/Wheat1.png";
        setTimeout(UpdateFarm1, 80000);
      }
    }else if(vegetable == 4){
      if(onions > 0){
        farm1taken = 41;
        onions -= 1;
        UpdateStock();
        document.getElementById("Image1").src = "Images/Onion/Onion1.png";
        setTimeout(UpdateFarm1, 120000);
      }
    }
  }else if(farm1taken == 15){
    farm1taken = 0;
    document.getElementById("Image1").src = "Images/FarmLand.png";
    potatoes += 3;
    UpdateStock();
    AddToConsole("Harvested Potatoes!")
  }else if(farm1taken == 25){
    farm1taken = 0;
    document.getElementById("Image1").src = "Images/FarmLand.png";
    carrots += 3;
    UpdateStock();
    AddToConsole("Harvested Carrots!")
  }else if(farm1taken == 35){
    farm1taken = 0;
    document.getElementById("Image1").src = "Images/FarmLand.png";
    wheat += 3;
    UpdateStock();
    AddToConsole("Harvested Wheat!")
  }else if(farm1taken == 45){
    farm1taken = 0;
    document.getElementById("Image1").src = "Images/FarmLand.png";
    onions += 3;
    UpdateStock();
    AddToConsole("Harvested Onions!")
  }
}

function UpdateFarm1(){
  if(farm1taken == 11){
    document.getElementById("Image1").src = "Images/Potato/Potato2.png";
    farm1taken = 12;
    setTimeout(UpdateFarm1, 60000);
  }else if(farm1taken == 12){
    document.getElementById("Image1").src = "Images/Potato/Potato3.png";
    farm1taken = 13;
    setTimeout(UpdateFarm1, 60000);
  }else if(farm1taken == 13){
    document.getElementById("Image1").src = "Images/Potato/Potato4.png";
    farm1taken = 14;
    setTimeout(UpdateFarm1, 60000);
  }else if(farm1taken == 14){
    document.getElementById("Image1").src = "Images/Potato/Potato5.png";
    farm1taken = 15;
  }else if(farm1taken == 21){
    document.getElementById("Image1").src = "Images/Carrot/Carrot2.png";
    farm1taken = 22;
    setTimeout(UpdateFarm1, 55000);
  }else if(farm1taken == 22){
    document.getElementById("Image1").src = "Images/Carrot/Carrot3.png";
    farm1taken = 23;
    setTimeout(UpdateFarm1, 55000);
  }else if(farm1taken == 23){
    document.getElementById("Image1").src = "Images/Carrot/Carrot4.png";
    farm1taken = 24;
    setTimeout(UpdateFarm1, 55000);
  }else if(farm1taken == 24){
    document.getElementById("Image1").src = "Images/Carrot/Carrot5.png";
    farm1taken = 25;
  }else if(farm1taken == 31){
    document.getElementById("Image1").src = "Images/Wheat/Wheat2.png";
    farm1taken = 32;
    setTimeout(UpdateFarm1, 80000);
  }else if(farm1taken == 32){
    document.getElementById("Image1").src = "Images/Wheat/Wheat3.png";
    farm1taken = 33;
    setTimeout(UpdateFarm1, 80000);
  }else if(farm1taken == 33){
    document.getElementById("Image1").src = "Images/Wheat/Wheat4.png";
    farm1taken = 34;
    setTimeout(UpdateFarm1, 80000);
  }else if(farm1taken == 34){
    document.getElementById("Image1").src = "Images/Wheat/Wheat5.png";
    farm1taken = 35;
  }else if(farm1taken == 41){
    document.getElementById("Image1").src = "Images/Onion/Onion2.png";
    farm1taken = 42;
    setTimeout(UpdateFarm1, 120000);
  }else if(farm1taken == 42){
    document.getElementById("Image1").src = "Images/Onion/Onion3.png";
    farm1taken = 43;
    setTimeout(UpdateFarm1, 120000);
  }else if(farm1taken == 43){
    document.getElementById("Image1").src = "Images/Onion/Onion4.png";
    farm1taken = 44;
    setTimeout(UpdateFarm1, 120000);
  }else if(farm1taken == 44){
    document.getElementById("Image1").src = "Images/Onion/Onion5.png";
    farm1taken = 45;
  }
}

function Farm2(){
  if(farm2taken == 0){
    if(vegetable == 1){
      if(potatoes > 0){
        farm2taken = 11;
        potatoes -= 1;
        UpdateStock();
        document.getElementById("Image2").src = "Images/Potato/Potato1.png";
        setTimeout(UpdateFarm2, 60000);
      }
    }else if(vegetable == 2){
      if(carrots > 0){
        farm2taken = 21;
        carrots -= 1;
        UpdateStock();
        document.getElementById("Image2").src = "Images/Carrot/Carrot1.png";
        setTimeout(UpdateFarm2, 55000);
      }
    }else if(vegetable == 3){
      if(wheat > 0){
        farm2taken = 31;
        wheat -= 1;
        UpdateStock();
        document.getElementById("Image2").src = "Images/Wheat/Wheat1.png";
        setTimeout(UpdateFarm2, 80000);
      }
    }else if(vegetable == 4){
      if(onions > 0){
        farm2taken = 41;
        onions -= 1;
        UpdateStock();
        document.getElementById("Image2").src = "Images/Onion/Onion1.png";
        setTimeout(UpdateFarm2, 120000);
      }
    }
  }else if(farm2taken == 15){
    farm2taken = 0;
    document.getElementById("Image2").src = "Images/FarmLand.png";
    potatoes += 3;
    UpdateStock();
    AddToConsole("Harvested Potatoes!")
  }else if(farm2taken == 25){
    farm2taken = 0;
    document.getElementById("Image2").src = "Images/FarmLand.png";
    carrots += 3;
    UpdateStock();
    AddToConsole("Harvested Carrots!")
  }else if(farm2taken == 35){
    farm2taken = 0;
    document.getElementById("Image2").src = "Images/FarmLand.png";
    wheat += 3;
    UpdateStock();
    AddToConsole("Harvested Wheat!")
  }else if(farm2taken == 45){
    farm2taken = 0;
    document.getElementById("Image2").src = "Images/FarmLand.png";
    onions += 3;
    UpdateStock();
    AddToConsole("Harvested Onions!")
  }
}

function UpdateFarm2(){
  if(farm2taken == 11){
    document.getElementById("Image2").src = "Images/Potato/Potato2.png";
    farm2taken = 12;
    setTimeout(UpdateFarm2, 60000);
  }else if(farm2taken == 12){
    document.getElementById("Image2").src = "Images/Potato/Potato3.png";
    farm2taken = 13;
    setTimeout(UpdateFarm2, 60000);
  }else if(farm2taken == 13){
    document.getElementById("Image2").src = "Images/Potato/Potato4.png";
    farm2taken = 14;
    setTimeout(UpdateFarm2, 60000);
  }else if(farm2taken == 14){
    document.getElementById("Image2").src = "Images/Potato/Potato5.png";
    farm2taken = 15;
  }else if(farm2taken == 21){
    document.getElementById("Image2").src = "Images/Carrot/Carrot2.png";
    farm2taken = 22;
    setTimeout(UpdateFarm2, 55000);
  }else if(farm2taken == 22){
    document.getElementById("Image2").src = "Images/Carrot/Carrot3.png";
    farm2taken = 23;
    setTimeout(UpdateFarm2, 55000);
  }else if(farm2taken == 23){
    document.getElementById("Image2").src = "Images/Carrot/Carrot4.png";
    farm2taken = 24;
    setTimeout(UpdateFarm2, 55000);
  }else if(farm2taken == 24){
    document.getElementById("Image2").src = "Images/Carrot/Carrot5.png";
    farm2taken = 25;
  }else if(farm2taken == 31){
    document.getElementById("Image2").src = "Images/Wheat/Wheat2.png";
    farm2taken = 32;
    setTimeout(UpdateFarm2, 80000);
  }else if(farm2taken == 32){
    document.getElementById("Image2").src = "Images/Wheat/Wheat3.png";
    farm2taken = 33;
    setTimeout(UpdateFarm2, 80000);
  }else if(farm2taken == 33){
    document.getElementById("Image2").src = "Images/Wheat/Wheat4.png";
    farm2taken = 34;
    setTimeout(UpdateFarm2, 80000);
  }else if(farm2taken == 34){
    document.getElementById("Image2").src = "Images/Wheat/Wheat5.png";
    farm2taken = 35;
  }else if(farm2taken == 41){
    document.getElementById("Image2").src = "Images/Onion/Onion2.png";
    farm2taken = 42;
    setTimeout(UpdateFarm2, 120000);
  }else if(farm2taken == 42){
    document.getElementById("Image2").src = "Images/Onion/Onion3.png";
    farm2taken = 43;
    setTimeout(UpdateFarm2, 120000);
  }else if(farm2taken == 43){
    document.getElementById("Image2").src = "Images/Onion/Onion4.png";
    farm2taken = 44;
    setTimeout(UpdateFarm2, 120000);
  }else if(farm2taken == 44){
    document.getElementById("Image2").src = "Images/Onion/Onion5.png";
    farm2taken = 45;
  }
}

function Farm3(){
  if(farm3taken == 0){
    if(vegetable == 1){
      if(potatoes > 0){
        farm3taken = 11;
        potatoes -= 1;
        UpdateStock();
        document.getElementById("Image3").src = "Images/Potato/Potato1.png";
        setTimeout(UpdateFarm3, 60000);
      }
    }else if(vegetable == 2){
      if(carrots > 0){
        farm3taken = 21;
        carrots -= 1;
        UpdateStock();
        document.getElementById("Image3").src = "Images/Carrot/Carrot1.png";
        setTimeout(UpdateFarm3, 55000);
      }
    }else if(vegetable == 3){
      if(wheat > 0){
        farm3taken = 31;
        wheat -= 1;
        UpdateStock();
        document.getElementById("Image3").src = "Images/Wheat/Wheat1.png";
        setTimeout(UpdateFarm3, 80000);
      }
    }else if(vegetable == 4){
      if(onions > 0){
        farm3taken = 41;
        onions -= 1;
        UpdateStock();
        document.getElementById("Image3").src = "Images/Onion/Onion1.png";
        setTimeout(UpdateFarm3, 120000);
      }
    }
  }else if(farm3taken == 15){
    farm3taken = 0;
    document.getElementById("Image3").src = "Images/FarmLand.png";
    potatoes += 3;
    UpdateStock();
    AddToConsole("Harvested Potatoes!")
  }else if(farm3taken == 25){
    farm3taken = 0;
    document.getElementById("Image3").src = "Images/FarmLand.png";
    carrots += 3;
    UpdateStock();
    AddToConsole("Harvested Carrots!")
  }else if(farm3taken == 35){
    farm3taken = 0;
    document.getElementById("Image3").src = "Images/FarmLand.png";
    wheat += 3;
    UpdateStock();
    AddToConsole("Harvested Wheat!")
  }else if(farm3taken == 45){
    farm3taken = 0;
    document.getElementById("Image3").src = "Images/FarmLand.png";
    onions += 3;
    UpdateStock();
    AddToConsole("Harvested Onions!")
  }
}

function UpdateFarm3(){
  if(farm3taken == 11){
    document.getElementById("Image3").src = "Images/Potato/Potato2.png";
    farm3taken = 12;
    setTimeout(UpdateFarm3, 60000);
  }else if(farm3taken == 12){
    document.getElementById("Image3").src = "Images/Potato/Potato3.png";
    farm3taken = 13;
    setTimeout(UpdateFarm3, 60000);
  }else if(farm3taken == 13){
    document.getElementById("Image3").src = "Images/Potato/Potato4.png";
    farm3taken = 14;
    setTimeout(UpdateFarm3, 60000);
  }else if(farm3taken == 14){
    document.getElementById("Image3").src = "Images/Potato/Potato5.png";
    farm3taken = 15;
  }else if(farm3taken == 21){
    document.getElementById("Image3").src = "Images/Carrot/Carrot2.png";
    farm3taken = 22;
    setTimeout(UpdateFarm3, 55000);
  }else if(farm3taken == 22){
    document.getElementById("Image3").src = "Images/Carrot/Carrot3.png";
    farm3taken = 23;
    setTimeout(UpdateFarm3, 55000);
  }else if(farm3taken == 23){
    document.getElementById("Image3").src = "Images/Carrot/Carrot4.png";
    farm3taken = 24;
    setTimeout(UpdateFarm3, 55000);
  }else if(farm3taken == 24){
    document.getElementById("Image3").src = "Images/Carrot/Carrot5.png";
    farm3taken = 25;
  }else if(farm3taken == 31){
    document.getElementById("Image3").src = "Images/Wheat/Wheat2.png";
    farm3taken = 32;
    setTimeout(UpdateFarm3, 80000);
  }else if(farm3taken == 32){
    document.getElementById("Image3").src = "Images/Wheat/Wheat3.png";
    farm3taken = 33;
    setTimeout(UpdateFarm3, 80000);
  }else if(farm3taken == 33){
    document.getElementById("Image3").src = "Images/Wheat/Wheat4.png";
    farm3taken = 34;
    setTimeout(UpdateFarm3, 80000);
  }else if(farm3taken == 34){
    document.getElementById("Image3").src = "Images/Wheat/Wheat5.png";
    farm3taken = 35;
  }else if(farm3taken == 41){
    document.getElementById("Image3").src = "Images/Onion/Onion2.png";
    farm3taken = 42;
    setTimeout(UpdateFarm3, 120000);
  }else if(farm3taken == 42){
    document.getElementById("Image3").src = "Images/Onion/Onion3.png";
    farm3taken = 43;
    setTimeout(UpdateFarm3, 120000);
  }else if(farm3taken == 43){
    document.getElementById("Image3").src = "Images/Onion/Onion4.png";
    farm3taken = 44;
    setTimeout(UpdateFarm3, 120000);
  }else if(farm3taken == 44){
    document.getElementById("Image3").src = "Images/Onion/Onion5.png";
    farm3taken = 45;
  }
}

function Farm4(){
  if(farm4taken == 0){
    if(vegetable == 1){
      if(potatoes > 0){
        farm4taken = 11;
        potatoes -= 1;
        UpdateStock();
        document.getElementById("Image4").src = "Images/Potato/Potato1.png";
        setTimeout(UpdateFarm4, 60000);
      }
    }else if(vegetable == 2){
      if(carrots > 0){
        farm4taken = 21;
        carrots -= 1;
        UpdateStock();
        document.getElementById("Image4").src = "Images/Carrot/Carrot1.png";
        setTimeout(UpdateFarm4, 55000);
      }
    }else if(vegetable == 3){
      if(wheat > 0){
        farm4taken = 31;
        wheat -= 1;
        UpdateStock();
        document.getElementById("Image4").src = "Images/Wheat/Wheat1.png";
        setTimeout(UpdateFarm4, 80000);
      }
    }else if(vegetable == 4){
      if(onions > 0){
        farm4taken = 41;
        onions -= 1;
        UpdateStock();
        document.getElementById("Image4").src = "Images/Onion/Onion1.png";
        setTimeout(UpdateFarm4, 120000);
      }
    }
  }else if(farm4taken == 15){
    farm4taken = 0;
    document.getElementById("Image4").src = "Images/FarmLand.png";
    potatoes += 3;
    UpdateStock();
    AddToConsole("Harvested Potatoes!")
  }else if(farm4taken == 25){
    farm4taken = 0;
    document.getElementById("Image4").src = "Images/FarmLand.png";
    carrots += 3;
    UpdateStock();
    AddToConsole("Harvested Carrots!")
  }else if(farm4taken == 35){
    farm4taken = 0;
    document.getElementById("Image4").src = "Images/FarmLand.png";
    wheat += 3;
    UpdateStock();
    AddToConsole("Harvested Wheat!")
  }else if(farm4taken == 45){
    farm4taken = 0;
    document.getElementById("Image4").src = "Images/FarmLand.png";
    onions += 3;
    UpdateStock();
    AddToConsole("Harvested Onions!")
  }
}

function UpdateFarm4(){
  if(farm4taken == 11){
    document.getElementById("Image4").src = "Images/Potato/Potato2.png";
    farm4taken = 12;
    setTimeout(UpdateFarm4, 60000);
  }else if(farm4taken == 12){
    document.getElementById("Image4").src = "Images/Potato/Potato3.png";
    farm4taken = 13;
    setTimeout(UpdateFarm4, 60000);
  }else if(farm4taken == 13){
    document.getElementById("Image4").src = "Images/Potato/Potato4.png";
    farm4taken = 14;
    setTimeout(UpdateFarm4, 60000);
  }else if(farm4taken == 14){
    document.getElementById("Image4").src = "Images/Potato/Potato5.png";
    farm4taken = 15;
  }else if(farm4taken == 21){
    document.getElementById("Image4").src = "Images/Carrot/Carrot2.png";
    farm4taken = 22;
    setTimeout(UpdateFarm4, 55000);
  }else if(farm4taken == 22){
    document.getElementById("Image4").src = "Images/Carrot/Carrot3.png";
    farm4taken = 23;
    setTimeout(UpdateFarm4, 55000);
  }else if(farm4taken == 23){
    document.getElementById("Image4").src = "Images/Carrot/Carrot4.png";
    farm4taken = 24;
    setTimeout(UpdateFarm4, 55000);
  }else if(farm4taken == 24){
    document.getElementById("Image4").src = "Images/Carrot/Carrot5.png";
    farm4taken = 25;
  }else if(farm4taken == 31){
    document.getElementById("Image4").src = "Images/Wheat/Wheat2.png";
    farm4taken = 32;
    setTimeout(UpdateFarm4, 80000);
  }else if(farm4taken == 32){
    document.getElementById("Image4").src = "Images/Wheat/Wheat3.png";
    farm4taken = 33;
    setTimeout(UpdateFarm4, 80000);
  }else if(farm4taken == 33){
    document.getElementById("Image4").src = "Images/Wheat/Wheat4.png";
    farm4taken = 34;
    setTimeout(UpdateFarm4, 80000);
  }else if(farm4taken == 34){
    document.getElementById("Image4").src = "Images/Wheat/Wheat5.png";
    farm4taken = 35;
  }else if(farm4taken == 41){
    document.getElementById("Image4").src = "Images/Onion/Onion2.png";
    farm4taken = 42;
    setTimeout(UpdateFarm4, 120000);
  }else if(farm4taken == 42){
    document.getElementById("Image4").src = "Images/Onion/Onion3.png";
    farm4taken = 43;
    setTimeout(UpdateFarm4, 120000);
  }else if(farm4taken == 43){
    document.getElementById("Image4").src = "Images/Onion/Onion4.png";
    farm4taken = 44;
    setTimeout(UpdateFarm4, 120000);
  }else if(farm4taken == 44){
    document.getElementById("Image4").src = "Images/Onion/Onion5.png";
    farm4taken = 45;
  }
}

function Farm5(){
  if(farm5taken == 0){
    if(vegetable == 1){
      if(potatoes > 0){
        farm5taken = 11;
        potatoes -= 1;
        UpdateStock();
        document.getElementById("Image5").src = "Images/Potato/Potato1.png";
        setTimeout(UpdateFarm5, 60000);
      }
    }else if(vegetable == 2){
      if(carrots > 0){
        farm5taken = 21;
        carrots -= 1;
        UpdateStock();
        document.getElementById("Image5").src = "Images/Carrot/Carrot1.png";
        setTimeout(UpdateFarm5, 55000);
      }
    }else if(vegetable == 3){
      if(wheat > 0){
        farm5taken = 31;
        wheat -= 1;
        UpdateStock();
        document.getElementById("Image5").src = "Images/Wheat/Wheat1.png";
        setTimeout(UpdateFarm5, 80000);
      }
    }else if(vegetable == 4){
      if(onions > 0){
        farm5taken = 41;
        onions -= 1;
        UpdateStock();
        document.getElementById("Image5").src = "Images/Onion/Onion1.png";
        setTimeout(UpdateFarm5, 120000);
      }
    }
  }else if(farm5taken == 15){
    farm5taken = 0;
    document.getElementById("Image5").src = "Images/FarmLand.png";
    potatoes += 3;
    UpdateStock();
    AddToConsole("Harvested Potatoes!")
  }else if(farm5taken == 25){
    farm5taken = 0;
    document.getElementById("Image5").src = "Images/FarmLand.png";
    carrots += 3;
    UpdateStock();
    AddToConsole("Harvested Carrots!")
  }else if(farm5taken == 35){
    farm5taken = 0;
    document.getElementById("Image5").src = "Images/FarmLand.png";
    wheat += 3;
    UpdateStock();
    AddToConsole("Harvested Wheat!")
  }else if(farm5taken == 45){
    farm5taken = 0;
    document.getElementById("Image5").src = "Images/FarmLand.png";
    onions += 3;
    UpdateStock();
    AddToConsole("Harvested Onions!")
  }
}

function UpdateFarm5(){
  if(farm5taken == 11){
    document.getElementById("Image5").src = "Images/Potato/Potato2.png";
    farm5taken = 12;
    setTimeout(UpdateFarm5, 60000);
  }else if(farm5taken == 12){
    document.getElementById("Image5").src = "Images/Potato/Potato3.png";
    farm5taken = 13;
    setTimeout(UpdateFarm5, 60000);
  }else if(farm5taken == 13){
    document.getElementById("Image5").src = "Images/Potato/Potato4.png";
    farm5taken = 14;
    setTimeout(UpdateFarm5, 60000);
  }else if(farm5taken == 14){
    document.getElementById("Image5").src = "Images/Potato/Potato5.png";
    farm5taken = 15;
  }else if(farm5taken == 21){
    document.getElementById("Image5").src = "Images/Carrot/Carrot2.png";
    farm5taken = 22;
    setTimeout(UpdateFarm5, 55000);
  }else if(farm5taken == 22){
    document.getElementById("Image5").src = "Images/Carrot/Carrot3.png";
    farm5taken = 23;
    setTimeout(UpdateFarm5, 55000);
  }else if(farm5taken == 23){
    document.getElementById("Image5").src = "Images/Carrot/Carrot4.png";
    farm5taken = 24;
    setTimeout(UpdateFarm5, 55000);
  }else if(farm5taken == 24){
    document.getElementById("Image5").src = "Images/Carrot/Carrot5.png";
    farm5taken = 25;
  }else if(farm5taken == 31){
    document.getElementById("Image5").src = "Images/Wheat/Wheat2.png";
    farm5taken = 32;
    setTimeout(UpdateFarm5, 80000);
  }else if(farm5taken == 32){
    document.getElementById("Image5").src = "Images/Wheat/Wheat3.png";
    farm5taken = 33;
    setTimeout(UpdateFarm5, 80000);
  }else if(farm5taken == 33){
    document.getElementById("Image5").src = "Images/Wheat/Wheat4.png";
    farm5taken = 34;
    setTimeout(UpdateFarm5, 80000);
  }else if(farm5taken == 34){
    document.getElementById("Image5").src = "Images/Wheat/Wheat5.png";
    farm5taken = 35;
  }else if(farm5taken == 41){
    document.getElementById("Image5").src = "Images/Onion/Onion2.png";
    farm5taken = 42;
    setTimeout(UpdateFarm5, 120000);
  }else if(farm5taken == 42){
    document.getElementById("Image5").src = "Images/Onion/Onion3.png";
    farm5taken = 43;
    setTimeout(UpdateFarm5, 120000);
  }else if(farm5taken == 43){
    document.getElementById("Image5").src = "Images/Onion/Onion4.png";
    farm5taken = 44;
    setTimeout(UpdateFarm5, 120000);
  }else if(farm5taken == 44){
    document.getElementById("Image5").src = "Images/Onion/Onion5.png";
    farm5taken = 45;
  }
}

function Farm6(){
  if(farm6taken == 0){
    if(vegetable == 1){
      if(potatoes > 0){
        farm6taken = 11;
        potatoes -= 1;
        UpdateStock();
        document.getElementById("Image6").src = "Images/Potato/Potato1.png";
        setTimeout(UpdateFarm6, 60000);
      }
    }else if(vegetable == 2){
      if(carrots > 0){
        farm6taken = 21;
        carrots -= 1;
        UpdateStock();
        document.getElementById("Image6").src = "Images/Carrot/Carrot1.png";
        setTimeout(UpdateFarm6, 55000);
      }
    }else if(vegetable == 3){
      if(wheat > 0){
        farm6taken = 31;
        wheat -= 1;
        UpdateStock();
        document.getElementById("Image6").src = "Images/Wheat/Wheat1.png";
        setTimeout(UpdateFarm6, 80000);
      }
    }else if(vegetable == 4){
      if(onions > 0){
        farm6taken = 41;
        onions -= 1;
        UpdateStock();
        document.getElementById("Image6").src = "Images/Onion/Onion1.png";
        setTimeout(UpdateFarm6, 120000);
      }
    }
  }else if(farm6taken == 15){
    farm6taken = 0;
    document.getElementById("Image6").src = "Images/FarmLand.png";
    potatoes += 3;
    UpdateStock();
    AddToConsole("Harvested Potatoes!")
  }else if(farm6taken == 25){
    farm6taken = 0;
    document.getElementById("Image6").src = "Images/FarmLand.png";
    carrots += 3;
    UpdateStock();
    AddToConsole("Harvested Carrots!")
  }else if(farm6taken == 35){
    farm6taken = 0;
    document.getElementById("Image6").src = "Images/FarmLand.png";
    wheat += 3;
    UpdateStock();
    AddToConsole("Harvested Wheat!")
  }else if(farm6taken == 45){
    farm6taken = 0;
    document.getElementById("Image6").src = "Images/FarmLand.png";
    onions += 3;
    UpdateStock();
    AddToConsole("Harvested Onions!")
  }
}

function UpdateFarm6(){
  if(farm6taken == 11){
    document.getElementById("Image6").src = "Images/Potato/Potato2.png";
    farm6taken = 12;
    setTimeout(UpdateFarm6, 60000);
  }else if(farm6taken == 12){
    document.getElementById("Image6").src = "Images/Potato/Potato3.png";
    farm6taken = 13;
    setTimeout(UpdateFarm6, 60000);
  }else if(farm6taken == 13){
    document.getElementById("Image6").src = "Images/Potato/Potato4.png";
    farm6taken = 14;
    setTimeout(UpdateFarm6, 60000);
  }else if(farm6taken == 14){
    document.getElementById("Image6").src = "Images/Potato/Potato5.png";
    farm6taken = 15;
  }else if(farm6taken == 21){
    document.getElementById("Image6").src = "Images/Carrot/Carrot2.png";
    farm6taken = 22;
    setTimeout(UpdateFarm6, 55000);
  }else if(farm6taken == 22){
    document.getElementById("Image6").src = "Images/Carrot/Carrot3.png";
    farm6taken = 23;
    setTimeout(UpdateFarm6, 55000);
  }else if(farm6taken == 23){
    document.getElementById("Image6").src = "Images/Carrot/Carrot4.png";
    farm6taken = 24;
    setTimeout(UpdateFarm6, 55000);
  }else if(farm6taken == 24){
    document.getElementById("Image6").src = "Images/Carrot/Carrot5.png";
    farm6taken = 25;
  }else if(farm6taken == 31){
    document.getElementById("Image6").src = "Images/Wheat/Wheat2.png";
    farm6taken = 32;
    setTimeout(UpdateFarm6, 80000);
  }else if(farm6taken == 32){
    document.getElementById("Image6").src = "Images/Wheat/Wheat3.png";
    farm6taken = 33;
    setTimeout(UpdateFarm6, 80000);
  }else if(farm6taken == 33){
    document.getElementById("Image6").src = "Images/Wheat/Wheat4.png";
    farm6taken = 34;
    setTimeout(UpdateFarm6, 80000);
  }else if(farm6taken == 34){
    document.getElementById("Image6").src = "Images/Wheat/Wheat5.png";
    farm6taken = 35;
  }else if(farm6taken == 41){
    document.getElementById("Image6").src = "Images/Onion/Onion2.png";
    farm6taken = 42;
    setTimeout(UpdateFarm6, 120000);
  }else if(farm6taken == 42){
    document.getElementById("Image6").src = "Images/Onion/Onion3.png";
    farm6taken = 43;
    setTimeout(UpdateFarm6, 120000);
  }else if(farm6taken == 43){
    document.getElementById("Image6").src = "Images/Onion/Onion4.png";
    farm6taken = 44;
    setTimeout(UpdateFarm6, 120000);
  }else if(farm6taken == 44){
    document.getElementById("Image6").src = "Images/Onion/Onion5.png";
    farm6taken = 45;
  }
}

function Farm7(){
  if(farm7taken == 0){
    if(vegetable == 1){
      if(potatoes > 0){
        farm7taken = 11;
        potatoes -= 1;
        UpdateStock();
        document.getElementById("Image7").src = "Images/Potato/Potato1.png";
        setTimeout(UpdateFarm7, 60000);
      }
    }else if(vegetable == 2){
      if(carrots > 0){
        farm7taken = 21;
        carrots -= 1;
        UpdateStock();
        document.getElementById("Image7").src = "Images/Carrot/Carrot1.png";
        setTimeout(UpdateFarm7, 55000);
      }
    }else if(vegetable == 3){
      if(wheat > 0){
        farm7taken = 31;
        wheat -= 1;
        UpdateStock();
        document.getElementById("Image7").src = "Images/Wheat/Wheat1.png";
        setTimeout(UpdateFarm7, 80000);
      }
    }else if(vegetable == 4){
        if(onions > 0){
        farm7taken = 41;
        onions -= 1;
        UpdateStock();
        document.getElementById("Image7").src = "Images/Onion/Onion1.png";
        setTimeout(UpdateFarm7, 120000);
      }
    }
  }else if(farm7taken == 15){
    farm7taken = 0;
    document.getElementById("Image7").src = "Images/FarmLand.png";
    potatoes += 3;
    UpdateStock();
    AddToConsole("Harvested Potatoes!")
  }else if(farm7taken == 25){
    farm7taken = 0;
    document.getElementById("Image7").src = "Images/FarmLand.png";
    carrots += 3;
    UpdateStock();
    AddToConsole("Harvested Carrots!")
  }else if(farm7taken == 35){
    farm7taken = 0;
    document.getElementById("Image7").src = "Images/FarmLand.png";
    wheat += 3;
    UpdateStock();
    AddToConsole("Harvested Wheat!")
  }else if(farm7taken == 45){
    farm7taken = 0;
    document.getElementById("Image7").src = "Images/FarmLand.png";
    onions += 3;
    UpdateStock();
    AddToConsole("Harvested Onions!")
  }
}

function UpdateFarm7(){
  if(farm7taken == 11){
    document.getElementById("Image7").src = "Images/Potato/Potato2.png";
    farm7taken = 12;
    setTimeout(UpdateFarm7, 60000);
  }else if(farm7taken == 12){
    document.getElementById("Image7").src = "Images/Potato/Potato3.png";
    farm7taken = 13;
    setTimeout(UpdateFarm7, 60000);
  }else if(farm7taken == 13){
    document.getElementById("Image7").src = "Images/Potato/Potato4.png";
    farm7taken = 14;
    setTimeout(UpdateFarm7, 60000);
  }else if(farm7taken == 14){
    document.getElementById("Image7").src = "Images/Potato/Potato5.png";
    farm7taken = 15;
  }else if(farm7taken == 21){
    document.getElementById("Image7").src = "Images/Carrot/Carrot2.png";
    farm7taken = 22;
    setTimeout(UpdateFarm7, 55000);
  }else if(farm7taken == 22){
    document.getElementById("Image7").src = "Images/Carrot/Carrot3.png";
    farm7taken = 23;
    setTimeout(UpdateFarm7, 55000);
  }else if(farm7taken == 23){
    document.getElementById("Image7").src = "Images/Carrot/Carrot4.png";
    farm7taken = 24;
    setTimeout(UpdateFarm7, 55000);
  }else if(farm7taken == 24){
    document.getElementById("Image7").src = "Images/Carrot/Carrot5.png";
    farm7taken = 25;
  }else if(farm7taken == 31){
    document.getElementById("Image7").src = "Images/Wheat/Wheat2.png";
    farm7taken = 32;
    setTimeout(UpdateFarm7, 80000);
  }else if(farm7taken == 32){
    document.getElementById("Image7").src = "Images/Wheat/Wheat3.png";
    farm7taken = 33;
    setTimeout(UpdateFarm7, 80000);
  }else if(farm7taken == 33){
    document.getElementById("Image7").src = "Images/Wheat/Wheat4.png";
    farm7taken = 34;
    setTimeout(UpdateFarm7, 80000);
  }else if(farm7taken == 34){
    document.getElementById("Image7").src = "Images/Wheat/Wheat5.png";
    farm7taken = 35;
  }else if(farm7taken == 41){
    document.getElementById("Image7").src = "Images/Onion/Onion2.png";
    farm7taken = 42;
    setTimeout(UpdateFarm7, 120000);
  }else if(farm7taken == 42){
    document.getElementById("Image7").src = "Images/Onion/Onion3.png";
    farm7taken = 43;
    setTimeout(UpdateFarm7, 120000);
  }else if(farm7taken == 43){
    document.getElementById("Image7").src = "Images/Onion/Onion4.png";
    farm7taken = 44;
    setTimeout(UpdateFarm7, 120000);
  }else if(farm7taken == 44){
    document.getElementById("Image7").src = "Images/Onion/Onion5.png";
    farm7taken = 45;
  }
}

function Farm8(){
  if(farm8taken == 0){
    if(vegetable == 1){
      if(potatoes > 0){
        farm8taken = 11;
        potatoes -= 1;
        UpdateStock();
        document.getElementById("Image8").src = "Images/Potato/Potato1.png";
        setTimeout(UpdateFarm8, 60000);
      }
    }else if(vegetable == 2){
      if(carrots > 0){
        farm8taken = 21;
        carrots -= 1;
        UpdateStock();
        document.getElementById("Image8").src = "Images/Carrot/Carrot1.png";
        setTimeout(UpdateFarm8, 55000);
      }
    }else if(vegetable == 3){
      if(wheat > 0){
        farm8taken = 31;
        wheat -= 1;
        UpdateStock();
        document.getElementById("Image8").src = "Images/Wheat/Wheat1.png";
        setTimeout(UpdateFarm8, 80000);
      }
    }else if(vegetable == 4){
      if(onions > 0){
        farm8taken = 41;
        onions -= 1;
        UpdateStock();
        document.getElementById("Image8").src = "Images/Onion/Onion1.png";
        setTimeout(UpdateFarm8, 120000);
      }
    }
  }else if(farm8taken == 15){
    farm8taken = 0;
    document.getElementById("Image8").src = "Images/FarmLand.png";
    potatoes += 3;
    UpdateStock();
    AddToConsole("Harvested Potatoes!")
  }else if(farm8taken == 25){
    farm8taken = 0;
    document.getElementById("Image8").src = "Images/FarmLand.png";
    carrots += 3;
    UpdateStock();
    AddToConsole("Harvested Carrots!")
  }else if(farm8taken == 35){
    farm8taken = 0;
    document.getElementById("Image8").src = "Images/FarmLand.png";
    wheat += 3;
    UpdateStock();
    AddToConsole("Harvested Wheat!")
  }else if(farm8taken == 45){
    farm8taken = 0;
    document.getElementById("Image8").src = "Images/FarmLand.png";
    onions += 3;
    UpdateStock();
    AddToConsole("Harvested Onions!")
  }
}

function UpdateFarm8(){
  if(farm8taken == 11){
    document.getElementById("Image8").src = "Images/Potato/Potato2.png";
    farm8taken = 12;
    setTimeout(UpdateFarm8, 60000);
  }else if(farm8taken == 12){
    document.getElementById("Image8").src = "Images/Potato/Potato3.png";
    farm8taken = 13;
    setTimeout(UpdateFarm8, 60000);
  }else if(farm8taken == 13){
    document.getElementById("Image8").src = "Images/Potato/Potato4.png";
    farm8taken = 14;
    setTimeout(UpdateFarm8, 60000);
  }else if(farm8taken == 14){
    document.getElementById("Image8").src = "Images/Potato/Potato5.png";
    farm8taken = 15;
  }else if(farm8taken == 21){
    document.getElementById("Image8").src = "Images/Carrot/Carrot2.png";
    farm8taken = 22;
    setTimeout(UpdateFarm8, 55000);
  }else if(farm8taken == 22){
    document.getElementById("Image8").src = "Images/Carrot/Carrot3.png";
    farm8taken = 23;
    setTimeout(UpdateFarm8, 55000);
  }else if(farm8taken == 23){
    document.getElementById("Image8").src = "Images/Carrot/Carrot4.png";
    farm8taken = 24;
    setTimeout(UpdateFarm8, 55000);
  }else if(farm8taken == 24){
    document.getElementById("Image8").src = "Images/Carrot/Carrot5.png";
    farm8taken = 25;
  }else if(farm8taken == 31){
    document.getElementById("Image8").src = "Images/Wheat/Wheat2.png";
    farm8taken = 32;
    setTimeout(UpdateFarm8, 80000);
  }else if(farm8taken == 32){
    document.getElementById("Image8").src = "Images/Wheat/Wheat3.png";
    farm8taken = 33;
    setTimeout(UpdateFarm8, 80000);
  }else if(farm8taken == 33){
    document.getElementById("Image8").src = "Images/Wheat/Wheat4.png";
    farm8taken = 34;
    setTimeout(UpdateFarm8, 80000);
  }else if(farm8taken == 34){
    document.getElementById("Image8").src = "Images/Wheat/Wheat5.png";
    farm8taken = 35;
  }else if(farm8taken == 41){
    document.getElementById("Image8").src = "Images/Onion/Onion2.png";
    farm8taken = 42;
    setTimeout(UpdateFarm8, 120000);
  }else if(farm8taken == 42){
    document.getElementById("Image8").src = "Images/Onion/Onion3.png";
    farm8taken = 43;
    setTimeout(UpdateFarm8, 120000);
  }else if(farm8taken == 43){
    document.getElementById("Image8").src = "Images/Onion/Onion4.png";
    farm8taken = 44;
    setTimeout(UpdateFarm8, 120000);
  }else if(farm8taken == 44){
    document.getElementById("Image8").src = "Images/Onion/Onion5.png";
    farm8taken = 45;
  }
}

function Farm9(){
  if(farm9taken == 0){
    if(vegetable == 1){
      if(potatoes > 0){
        farm9taken = 11;
        potatoes -= 1;
        UpdateStock();
        document.getElementById("Image9").src = "Images/Potato/Potato1.png";
        setTimeout(UpdateFarm9, 60000);
      }
    }else if(vegetable == 2){
      if(carrots > 0){
        farm9taken = 21;
        carrots -= 1;
        UpdateStock();
        document.getElementById("Image9").src = "Images/Carrot/Carrot1.png";
        setTimeout(UpdateFarm9, 55000);
      }
    }else if(vegetable == 3){
      if(wheat > 0){
        farm9taken = 31;
        wheat -= 1;
        UpdateStock();
        document.getElementById("Image9").src = "Images/Wheat/Wheat1.png";
        setTimeout(UpdateFarm9, 80000);
      }
    }else if(vegetable == 4){
      if(onions > 0){
        farm9taken = 41;
        onions -= 1;
        UpdateStock();
        document.getElementById("Image9").src = "Images/Onion/Onion1.png";
        setTimeout(UpdateFarm9, 120000);
      }
    }
  }else if(farm9taken == 15){
    farm9taken = 0;
    document.getElementById("Image9").src = "Images/FarmLand.png";
    potatoes += 3;
    UpdateStock();
    AddToConsole("Harvested Potatoes!")
  }else if(farm9taken == 25){
    farm9taken = 0;
    document.getElementById("Image9").src = "Images/FarmLand.png";
    carrots += 3;
    UpdateStock();
    AddToConsole("Harvested Carrots!")
  }else if(farm9taken == 35){
    farm9taken = 0;
    document.getElementById("Image9").src = "Images/FarmLand.png";
    wheat += 3;
    UpdateStock();
    AddToConsole("Harvested Wheat!")
  }else if(farm9taken == 45){
    farm9taken = 0;
    document.getElementById("Image9").src = "Images/FarmLand.png";
    onions += 3;
    UpdateStock();
    AddToConsole("Harvested Onions!")
  }
}

function UpdateFarm9(){
  if(farm9taken == 11){
    document.getElementById("Image9").src = "Images/Potato/Potato2.png";
    farm9taken = 12;
    setTimeout(UpdateFarm9, 60000);
  }else if(farm9taken == 12){
    document.getElementById("Image9").src = "Images/Potato/Potato3.png";
    farm9taken = 13;
    setTimeout(UpdateFarm9, 60000);
  }else if(farm9taken == 13){
    document.getElementById("Image9").src = "Images/Potato/Potato4.png";
    farm9taken = 14;
    setTimeout(UpdateFarm9, 60000);
  }else if(farm9taken == 14){
    document.getElementById("Image9").src = "Images/Potato/Potato5.png";
    farm9taken = 15;
  }else if(farm9taken == 21){
    document.getElementById("Image9").src = "Images/Carrot/Carrot2.png";
    farm9taken = 22;
    setTimeout(UpdateFarm9, 55000);
  }else if(farm9taken == 22){
    document.getElementById("Image9").src = "Images/Carrot/Carrot3.png";
    farm9taken = 23;
    setTimeout(UpdateFarm9, 55000);
  }else if(farm9taken == 23){
    document.getElementById("Image9").src = "Images/Carrot/Carrot4.png";
    farm9taken = 24;
    setTimeout(UpdateFarm9, 55000);
  }else if(farm9taken == 24){
    document.getElementById("Image9").src = "Images/Carrot/Carrot5.png";
    farm9taken = 25;
  }else if(farm9taken == 31){
    document.getElementById("Image9").src = "Images/Wheat/Wheat2.png";
    farm9taken = 32;
    setTimeout(UpdateFarm9, 80000);
  }else if(farm9taken == 32){
    document.getElementById("Image9").src = "Images/Wheat/Wheat3.png";
    farm9taken = 33;
    setTimeout(UpdateFarm9, 80000);
  }else if(farm9taken == 33){
    document.getElementById("Image9").src = "Images/Wheat/Wheat4.png";
    farm9taken = 34;
    setTimeout(UpdateFarm9, 80000);
  }else if(farm9taken == 34){
    document.getElementById("Image9").src = "Images/Wheat/Wheat5.png";
    farm9taken = 35;
  }else if(farm9taken == 41){
    document.getElementById("Image9").src = "Images/Onion/Onion2.png";
    farm9taken = 42;
    setTimeout(UpdateFarm9, 120000);
  }else if(farm9taken == 42){
    document.getElementById("Image9").src = "Images/Onion/Onion3.png";
    farm9taken = 43;
    setTimeout(UpdateFarm9, 120000);
  }else if(farm9taken == 43){
    document.getElementById("Image9").src = "Images/Onion/Onion4.png";
    farm9taken = 44;
    setTimeout(UpdateFarm9, 120000);
  }else if(farm9taken == 44){
    document.getElementById("Image9").src = "Images/Onion/Onion5.png";
    farm9taken = 45;
  }
}

function Farm10(){
  if(farm10taken == 0){
    if(vegetable == 1){
      if(potatoes > 0){
        farm10taken = 11;
        potatoes -= 1;
        UpdateStock();
        document.getElementById("Image10").src = "Images/Potato/Potato1.png";
        setTimeout(UpdateFarm10, 60000);
      }
    }else if(vegetable == 2){
      if(carrots > 0){
        farm10taken = 21;
        carrots -= 1;
        UpdateStock();
        document.getElementById("Image10").src = "Images/Carrot/Carrot1.png";
        setTimeout(UpdateFarm10, 55000);
      }
    }else if(vegetable == 3){
      if(wheat > 0){
        farm10taken = 31;
        wheat -= 1;
        UpdateStock();
        document.getElementById("Image10").src = "Images/Wheat/Wheat1.png";
        setTimeout(UpdateFarm10, 80000);
      }
    }else if(vegetable == 4){
      if(onions > 0){
        farm10taken = 41;
        onions -= 1;
        UpdateStock();
        document.getElementById("Image10").src = "Images/Onion/Onion1.png";
        setTimeout(UpdateFarm10, 120000);
      }
    }
  }else if(farm10taken == 15){
    farm10taken = 0;
    document.getElementById("Image10").src = "Images/FarmLand.png";
    potatoes += 3;
    UpdateStock();
    AddToConsole("Harvested Potatoes!")
  }else if(farm10taken == 25){
    farm10taken = 0;
    document.getElementById("Image10").src = "Images/FarmLand.png";
    carrots += 3;
    UpdateStock();
    AddToConsole("Harvested Carrots!")
  }else if(farm10taken == 35){
    farm10taken = 0;
    document.getElementById("Image10").src = "Images/FarmLand.png";
    wheat += 3;
    UpdateStock();
    AddToConsole("Harvested Wheat!")
  }else if(farm10taken == 45){
    farm10taken = 0;
    document.getElementById("Image10").src = "Images/FarmLand.png";
    onions += 3;
    UpdateStock();
    AddToConsole("Harvested Onions!")
  }
}

function UpdateFarm10(){
  if(farm10taken == 11){
    document.getElementById("Image10").src = "Images/Potato/Potato2.png";
    farm10taken = 12;
    setTimeout(UpdateFarm10, 60000);
  }else if(farm10taken == 12){
    document.getElementById("Image10").src = "Images/Potato/Potato3.png";
    farm10taken = 13;
    setTimeout(UpdateFarm10, 60000);
  }else if(farm10taken == 13){
    document.getElementById("Image10").src = "Images/Potato/Potato4.png";
    farm10taken = 14;
    setTimeout(UpdateFarm10, 60000);
  }else if(farm10taken == 14){
    document.getElementById("Image10").src = "Images/Potato/Potato5.png";
    farm10taken = 15;
  }else if(farm10taken == 21){
    document.getElementById("Image10").src = "Images/Carrot/Carrot2.png";
    farm10taken = 22;
    setTimeout(UpdateFarm10, 55000);
  }else if(farm10taken == 22){
    document.getElementById("Image10").src = "Images/Carrot/Carrot3.png";
    farm10taken = 23;
    setTimeout(UpdateFarm10, 55000);
  }else if(farm10taken == 23){
    document.getElementById("Image10").src = "Images/Carrot/Carrot4.png";
    farm10taken = 24;
    setTimeout(UpdateFarm10, 55000);
  }else if(farm10taken == 24){
    document.getElementById("Image10").src = "Images/Carrot/Carrot5.png";
    farm10taken = 25;
  }else if(farm10taken == 31){
    document.getElementById("Image10").src = "Images/Wheat/Wheat2.png";
    farm10taken = 32;
    setTimeout(UpdateFarm10, 80000);
  }else if(farm10taken == 32){
    document.getElementById("Image10").src = "Images/Wheat/Wheat3.png";
    farm10taken = 33;
    setTimeout(UpdateFarm10, 80000);
  }else if(farm10taken == 33){
    document.getElementById("Image10").src = "Images/Wheat/Wheat4.png";
    farm10taken = 34;
    setTimeout(UpdateFarm10, 80000);
  }else if(farm10taken == 34){
    document.getElementById("Image10").src = "Images/Wheat/Wheat5.png";
    farm10taken = 35;
  }else if(farm10taken == 41){
    document.getElementById("Image10").src = "Images/Onion/Onion2.png";
    farm10taken = 42;
    setTimeout(UpdateFarm10, 120000);
  }else if(farm10taken == 42){
    document.getElementById("Image10").src = "Images/Onion/Onion3.png";
    farm10taken = 43;
    setTimeout(UpdateFarm10, 120000);
  }else if(farm10taken == 43){
    document.getElementById("Image10").src = "Images/Onion/Onion4.png";
    farm10taken = 44;
    setTimeout(UpdateFarm10, 120000);
  }else if(farm10taken == 44){
    document.getElementById("Image10").src = "Images/Onion/Onion5.png";
    farm10taken = 45;
  }
}

function AddToConsole(text){
  var line1 = document.getElementById("Line1").innerHTML;
  var line2 = document.getElementById("Line2").innerHTML;
  var line3 = document.getElementById("Line3").innerHTML;
  document.getElementById("Line4").innerHTML = line3;
  document.getElementById("Line3").innerHTML = line2;
  document.getElementById("Line2").innerHTML = line1;
  document.getElementById("Line1").innerHTML = text;
}

function Console(){
  input = document.getElementById('Console').value;
  if(input == "SorryForTheLongPost"){
    potatoes += 50;
    document.getElementById("Console").value = "";
    UpdateStock();
    AddToConsole("Cheated Some Potatoes!");
  }else if(input == "Let'sGetCatEyes"){
    carrots += 50;
    document.getElementById("Console").value = "";
    UpdateStock();
    AddToConsole("Cheated Some Carrots!");
  }else if(input == "Bakin'Bread"){
    wheat += 50;
    document.getElementById("Console").value = "";
    UpdateStock();
    AddToConsole("Cheated Some Wheat!");
  }else if(input == "NoOnionNoCry"){
    onions += 50;
    document.getElementById("Console").value = "";
    UpdateStock();
    AddToConsole("Cheated Some Onions!");
  }else if(input == "Take 5 Potatoes"){
    potatoes -= 5;
    document.getElementById("Console").value = "";
    UpdateStock();
    AddToConsole("Took 5 Potatoes!");
  }
}

function UpdateStock(){
  document.getElementById("Potatoes").innerHTML = potatoes;
  document.getElementById("Carrots").innerHTML = carrots;
  document.getElementById("Wheat").innerHTML = wheat;
  document.getElementById("Onions").innerHTML = onions;
}